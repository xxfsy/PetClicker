﻿public enum ClickerUpgrades
{
    ClickerFirstUpgrade,
    ClickerSecondUpgrade
}
