﻿public enum AutoClickerUpgrades
{
    AutoClickerFirstUpgrade,
    AutoClickerSecondUpgrade
}
