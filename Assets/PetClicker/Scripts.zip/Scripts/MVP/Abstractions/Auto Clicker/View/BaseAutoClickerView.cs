﻿public abstract class BaseAutoClickerView : BaseView
{
    public abstract void DisplayNewIncomePerSecondFromModel(string newValue);
}
