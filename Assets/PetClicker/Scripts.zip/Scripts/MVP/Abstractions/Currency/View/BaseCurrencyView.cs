﻿public abstract class BaseCurrencyView : BaseView
{
    public abstract void DisplayNewCurrencyAmountFromSharedModel(string newValue);
}
