﻿// пока что просто как флаг
public abstract class BaseSignal
{

}
