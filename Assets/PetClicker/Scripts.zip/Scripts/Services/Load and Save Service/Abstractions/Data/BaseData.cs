public class BaseData
{

}
