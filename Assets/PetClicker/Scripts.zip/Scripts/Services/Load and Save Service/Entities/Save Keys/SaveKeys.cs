﻿
// перенес в отдельный файл, по идее так лучше
public static class SaveKeys
{
    // ключи для типов дат, в будущем можно будет добавить еще ключей для других дат : BaseData
    public const string GameDataKey = "GameData";
}
